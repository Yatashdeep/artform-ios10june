//
//  ThumbsViewController+SDVThumbsViewControllerPassThrough.h
//
//  modify ThumbsViewController to enable a subclass' super call to pass through
//
//  Created by Philipp Bohnenstengel on 03.11.14.
//
//

#import "ThumbsViewController.h"

@interface ThumbsViewController (SDVThumbsViewControllerPassThrough)

- (void)viewDidLoad;

@end
